###Meta-analysis prospective associations between substance use and suicidality
###Analysis using metafor

setwd("~/Dropbox/Recherche/GRIP/Charlie Rioux/Meta-analyse/Analysis")
library(readr)
library(metafor)

##########################
###SECONDARY PSYCHIATRIC DISORDER MODEL
###SU-SB
#########################

Data_SUSB <- read_csv("Data SUSB.csv")

##OVERALL EFFECT
#random effects model
#using Knapp and Hartung adjustment

SUSBoverall <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBoverall)

#model without wihtin-study variance
#significance of within study variance
SUSBnovar2 <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(0,NA), tdist = TRUE, data=Data_SUSB)
anova(SUSBoverall,SUSBnovar2)

#model without between-study variance
#significance of between study variance
SUSBnovar3 <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(NA,0), tdist = TRUE, data=Data_SUSB)
anova(SUSBoverall,SUSBnovar3)

#I2
W1 <- diag(1/Data_SUSB$v)
X1 <- model.matrix(SUSBoverall)
P1 <- W1 - W1 %*% X1 %*% solve(t(X1) %*% W1 %*% X1) %*% t(X1) %*% W1
I2SUSB <- 100 * sum(SUSBoverall$sigma2) / (sum(SUSBoverall$sigma2) + (SUSBoverall$p)/sum(diag(P1)))
I2SUSB
I2sepSUSB <- 100 * SUSBoverall$sigma2 / (sum(SUSBoverall$sigma2) + (SUSBoverall$k-SUSBoverall$p)/sum(diag(P1)))
I2sepSUSB

##MODERATORS

#Substance used
Subsg <- ifelse(Data_SUSB$Subs2=="1", yes=1, no=0)
Alc <- ifelse(Data_SUSB$Subs2=="2", yes=1, no=0)
Drug <- ifelse(Data_SUSB$Subs2=="3", yes=1, no=0)
SUSBalc <- rma.mv(logOR, v, mods = ~ Subsg + Drug, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBalc)
SUSBsubs <- rma.mv(logOR, v, mods = ~ Alc + Drug, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBsubs)
SUSBdrug <- rma.mv(logOR, v, mods = ~ Alc + Subsg, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBdrug)

  #significance of within study variance
SUSBalcnovar2 <- rma.mv(logOR, v, mods = ~ Subsg + Drug, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(0,NA), tdist = TRUE, data=Data_SUSB)
anova(SUSBalc,SUSBalcnovar2)

  #significance of between study variance
SUSBalcnovar3 <- rma.mv(logOR, v, mods = ~ Subsg + Drug, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(NA,0), tdist = TRUE, data=Data_SUSB)
anova(SUSBalc,SUSBalcnovar3)

#Substance used with cannabis
Subsgc <- ifelse(Data_SUSB$Subs=="1", yes=1, no=0)
Alcc <- ifelse(Data_SUSB$Subs=="2", yes=1, no=0)
Canc <- ifelse(Data_SUSB$Subs=="3", yes=1, no=0)
Drugc <- ifelse(Data_SUSB$Subs=="4", yes=1, no=0)
SUSBalcc <- rma.mv(logOR, v, mods = ~ Subsgc + +Canc + Drugc, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBalcc)
SUSBsubsc <- rma.mv(logOR, v, mods = ~ Alcc + Canc + Drugc, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBsubsc)
SUSBdrugc <- rma.mv(logOR, v, mods = ~ Alcc + Canc + Subsgc, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBdrugc)
SUSBcanc <- rma.mv(logOR, v, mods = ~ Alcc + Drugc + Subsgc, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBcanc)

#Suicidal behavior
Beh <- ifelse(Data_SUSB$Suic=="1", yes=1, no=0)
Ideation <- ifelse(Data_SUSB$Suic=="2", yes=1, no=0)
Attempt <- ifelse(Data_SUSB$Suic=="3", yes=1, no=0)
SUSBbeh <- rma.mv(logOR, v, mods = ~ Ideation + Attempt, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBbeh)
SUSBide <- rma.mv(logOR, v, mods = ~ Beh + Attempt, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBide)
SUSBatt <- rma.mv(logOR, v, mods = ~ Ideation + Beh, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBatt)

  #significance of within study variance
SUSBbehnovar2 <- rma.mv(logOR, v, mods = ~ Ideation + Attempt, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(0,NA), tdist = TRUE, data=Data_SUSB)
anova(SUSBbeh,SUSBbehnovar2)

  #significance of between study variance
SUSBbehnovar3 <- rma.mv(logOR, v, mods = ~ Ideation + Attempt, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(NA,0), tdist = TRUE, data=Data_SUSB)
anova(SUSBbeh,SUSBbehnovar3)

#Study design
SUSBdesign <- rma.mv(logOR, v, mods = ~ Design, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBdesign)
Design2 <- ifelse(Data_SUSB$Design=="1", yes=0, no=1)
SUSBdesign2 <- rma.mv(logOR, v, mods = ~ Design2, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBdesign2)

  #significance of within study variance
SUSBdesignnovar2 <- rma.mv(logOR, v, mods = ~ Design, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(0,NA), tdist = TRUE, data=Data_SUSB)
anova(SUSBdesign,SUSBdesignnovar2)

  #significance of between study variance
SUSBdesignnovar3 <- rma.mv(logOR, v, mods = ~ Design, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(NA,0), tdist = TRUE, data=Data_SUSB)
anova(SUSBdesign,SUSBdesignnovar3)

#Follow up length
flength <- (Data_SUSB$Follow - 71) #center around mean
SUSBfollow <- rma.mv(logOR, v, mods = ~ flength, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBfollow)

  #significance of within study variance
SUSBfollownovar2 <- rma.mv(logOR, v, mods = ~ flength, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(0,NA), tdist = TRUE, data=Data_SUSB)
anova(SUSBfollow,SUSBfollownovar2)

  #significance of between study variance
SUSBfollownovar3 <- rma.mv(logOR, v, mods = ~ flength, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(NA,0), tdist = TRUE, data=Data_SUSB)
anova(SUSBfollow,SUSBfollownovar3)

#Proportion male
sex <- (Data_SUSB$Male - 46) #center around mean
SUSBsex <- rma.mv(logOR, v, mods = ~ sex, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBsex)

  #significance of within study variance
SUSBsexnovar2 <- rma.mv(logOR, v, mods = ~ sex, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(0,NA), tdist = TRUE, data=Data_SUSB)
anova(SUSBsex,SUSBsexnovar2)

  #significance of between study variance
SUSBsexnovar3 <- rma.mv(logOR, v, mods = ~ sex, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(NA,0), tdist = TRUE, data=Data_SUSB)
anova(SUSBsex,SUSBsexnovar3)

#Proportion ethnic minority
ethnicity <- (Data_SUSB$Ethni - 29)
SUSBethni <- rma.mv(logOR, v, mods = ~ ethnicity, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBethni)

  #significance of within study variance
SUSBethninovar2 <- rma.mv(logOR, v, mods = ~ ethnicity, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(0,NA), tdist = TRUE, data=Data_SUSB)
anova(SUSBethni,SUSBethninovar2)

  #significance of between study variance
SUSBethninovar3 <- rma.mv(logOR, v, mods = ~ ethnicity, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(NA,0), tdist = TRUE, data=Data_SUSB)
anova(SUSBethni,SUSBethninovar3)

#Population type
Comm <- ifelse(Data_SUSB$Pop=="1", yes=1, no=0)
Risk <- ifelse(Data_SUSB$Pop=="2", yes=1, no=0)
Clinical <- ifelse(Data_SUSB$Pop=="3", yes=1, no=0)
SUSBcomm <- rma.mv(logOR, v, mods = ~ Risk + Clinical, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBcomm)
SUSBrisk <- rma.mv(logOR, v, mods = ~ Comm + Clinical, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBrisk)
SUSBclin <- rma.mv(logOR, v, mods = ~ Risk + Comm, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBclin)

  #significance of within study variance
SUSBcommnovar2 <- rma.mv(logOR, v, mods = ~ Risk + Clinical, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(0,NA), tdist = TRUE, data=Data_SUSB)
anova(SUSBcomm,SUSBcommnovar2)

  #significance of between study variance
SUSBcommnovar3 <- rma.mv(logOR, v, mods = ~ Risk + Clinical, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(NA,0), tdist = TRUE, data=Data_SUSB)
anova(SUSBcomm,SUSBcommnovar3)

#Year of publication
year <- (Data_SUSB$yearp - 2010) #center around mean
SUSBpubyear <- rma.mv(logOR, v, mods = ~ year, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBpubyear)

  #significance of within study variance
SUSBpubyearnovar2 <- rma.mv(logOR, v, mods = ~ year, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(0,NA), tdist = TRUE, data=Data_SUSB)
anova(SUSBpubyear,SUSBpubyearnovar2)

  #significance of between study variance
SUSBpubyearnovar3 <- rma.mv(logOR, v, mods = ~ year, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(NA,0), tdist = TRUE, data=Data_SUSB)
anova(SUSBpubyear,SUSBpubyearnovar3)

#Quality
Poor <- ifelse(Data_SUSB$Quality=="1", yes=1, no=0)
Good <- ifelse(Data_SUSB$Quality=="3", yes=1, no=0)
SUSBpoor <- rma.mv(logOR, v, mods = ~ Good, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBpoor)
SUSBgood <- rma.mv(logOR, v, mods = ~ Poor, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSB)
summary(SUSBgood)

##########################
###SECONDARY SUBSTANCE USE FISORDER MODEL
###SB-SU
#########################

Data_SBSU <- read_csv("Data SBSU.csv")

##OVERALL EFFECT
#random effects model
#using Knapp and Hartung adjustment

SBSUoverall <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUoverall)

#model without wihtin-study variance
#significance of within study variance
SBSUnovar2 <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(0,NA), tdist = TRUE, data=Data_SBSU)
anova(SBSUoverall,SBSUnovar2)

#model without between-study variance
#significance of between study variance
SBSUnovar3 <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(NA,0), tdist = TRUE, data=Data_SBSU)
anova(SBSUoverall,SBSUnovar3)

#I2
W2 <- diag(1/Data_SBSU$v)
X2 <- model.matrix(SBSUoverall)
P2 <- W2 - W2 %*% X2 %*% solve(t(X2) %*% W2 %*% X2) %*% t(X2) %*% W2
I2SBSU <- 100 * sum(SBSUoverall$sigma2) / (sum(SBSUoverall$sigma2) + (SBSUoverall$p)/sum(diag(P2)))
I2SBSU
I2sepSBSU <- 100 * SBSUoverall$sigma2 / (sum(SBSUoverall$sigma2) + (SBSUoverall$k-SBSUoverall$p)/sum(diag(P2)))
I2sepSBSU

##MODERATORS

#Substance used
Subsg2 <- ifelse(Data_SBSU$Subs2=="1", yes=1, no=0)
Alc2 <- ifelse(Data_SBSU$Subs2=="2", yes=1, no=0)
Drug2 <- ifelse(Data_SBSU$Subs2=="3", yes=1, no=0)
SBSUalc <- rma.mv(logOR, v, mods = ~ Subsg2 + Drug2, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUalc)
SBSUsubs <- rma.mv(logOR, v, mods = ~ Alc2 + Drug2, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUsubs)
SBSUdrug <- rma.mv(logOR, v, mods = ~ Alc2 + Subsg2, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUdrug)

  #significance of within study variance
SBSUalcnovar2 <- rma.mv(logOR, v, mods = ~ Subsg2 + Drug2, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(0,NA), tdist = TRUE, data=Data_SBSU)
anova(SBSUalc,SBSUalcnovar2)

  #significance of between study variance
SBSUalcnovar3 <- rma.mv(logOR, v, mods = ~ Subsg2 + Drug2, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(NA,0), tdist = TRUE, data=Data_SBSU)
anova(SBSUalc,SBSUalcnovar3)

#Substance used with cannabis
Subsg2c <- ifelse(Data_SBSU$Subs=="1", yes=1, no=0)
Alc2c <- ifelse(Data_SBSU$Subs=="2", yes=1, no=0)
Can2c <- ifelse(Data_SBSU$Subs=="3", yes=1, no=0)
Drug2c <- ifelse(Data_SBSU$Subs=="4", yes=1, no=0)
SBSUalcc <- rma.mv(logOR, v, mods = ~ Subsg2c + Drug2c + Can2c, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUalcc)
SBSUsubsc <- rma.mv(logOR, v, mods = ~ Alc2c + Drug2c + Can2c, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUsubsc)
SBSUdrugc <- rma.mv(logOR, v, mods = ~ Alc2c + Subsg2c + Can2c, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUdrugc)
SBSUcanc <- rma.mv(logOR, v, mods = ~ Alc2c + Subsg2c + Drug2c, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUcanc)

#Suicidal behavior
Beh2 <- ifelse(Data_SBSU$Suic=="1", yes=1, no=0)
Ideation2 <- ifelse(Data_SBSU$Suic=="2", yes=1, no=0)
Attempt2 <- ifelse(Data_SBSU$Suic=="3", yes=1, no=0)
SBSUbeh <- rma.mv(logOR, v, mods = ~ Ideation2 + Attempt2, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUbeh)
SBSUide <- rma.mv(logOR, v, mods = ~ Beh2 + Attempt2, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUide)
SBSUatt <- rma.mv(logOR, v, mods = ~ Ideation2 + Beh2, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUatt)

  #significance of within study variance
SBSUbehnovar2 <- rma.mv(logOR, v, mods = ~ Ideation2 + Attempt2, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(0,NA), tdist = TRUE, data=Data_SBSU)
anova(SBSUbeh,SBSUbehnovar2)

  #significance of between study variance
SBSUbehnovar3 <- rma.mv(logOR, v, mods = ~ Ideation2 + Attempt2, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(NA,0), tdist = TRUE, data=Data_SBSU)
anova(SBSUbeh,SBSUbehnovar3)

#Study design
SBSUdesign <- rma.mv(logOR, v, mods = ~ Design, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUdesign)
Design2SBSU <- ifelse(Data_SBSU$Design=="1", yes=0, no=1)
SBSUdesign2 <- rma.mv(logOR, v, mods = ~ Design2SBSU, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUdesign2)

  #significance of within study variance
SBSUdesignnovar2 <- rma.mv(logOR, v, mods = ~ Design, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(0,NA), tdist = TRUE, data=Data_SBSU)
anova(SBSUdesign,SBSUdesignnovar2)

  #significance of between study variance
SBSUdesignnovar3 <- rma.mv(logOR, v, mods = ~ Design, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(NA,0), tdist = TRUE, data=Data_SBSU)
anova(SBSUdesign,SBSUdesignnovar3)

#Follow up length
flength2 <- (Data_SBSU$Follow - 71) #center around mean
SBSUfollow <- rma.mv(logOR, v, mods = ~ flength2, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUfollow)

  #significance of within study variance
SBSUfollownovar2 <- rma.mv(logOR, v, mods = ~ flength2, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(0,NA), tdist = TRUE, data=Data_SBSU)
anova(SBSUfollow,SBSUfollownovar2)

  #significance of between study variance
SBSUfollownovar3 <- rma.mv(logOR, v, mods = ~ flength2, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(NA,0), tdist = TRUE, data=Data_SBSU)
anova(SBSUfollow,SBSUfollownovar3)

#Proportion male
sex2 <- (Data_SBSU$Male - 46) #center around mean
SBSUsex <- rma.mv(logOR, v, mods = ~ sex2, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUsex)

  #significance of within study variance
SBSUsexnovar2 <- rma.mv(logOR, v, mods = ~ sex2, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(0,NA), tdist = TRUE, data=Data_SBSU)
anova(SBSUsex,SBSUsexnovar2)

  #significance of between study variance
SBSUsexovar3 <- rma.mv(logOR, v, mods = ~ sex2, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(NA,0), tdist = TRUE, data=Data_SBSU)
anova(SBSUsex,SBSUsexovar3)

#Proportion ethnic minority
ethnicity2 <- (Data_SBSU$Ethni - 29)
SBSUethni <- rma.mv(logOR, v, mods = ~ ethnicity2, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUethni)

  #significance of within study variance
SBSUethninovar2 <- rma.mv(logOR, v, mods = ~ ethnicity2, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(0,NA), tdist = TRUE, data=Data_SBSU)
anova(SBSUethni,SBSUethninovar2)

  #significance of between study variance
SBSUethniovar3 <- rma.mv(logOR, v, mods = ~ ethnicity2, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(NA,0), tdist = TRUE, data=Data_SBSU)
anova(SBSUethni,SBSUethniovar3)


#Population type
Comm2 <- ifelse(Data_SBSU$Pop=="1", yes=1, no=0)
#Risk2 <- ifelse(Data_SBSU$Pop=="2", yes=1, no=0)
Clinical2 <- ifelse(Data_SBSU$Pop=="3", yes=1, no=0)
SBSUcomm <- rma.mv(logOR, v, mods = ~ Clinical2, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUcomm)
#SBSUrisk <- rma.mv(logOR, v, mods = ~ Comm2 + Clinical2, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
#summary(SBSUrisk)
SBSUclin <- rma.mv(logOR, v, mods = ~ Comm2, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUclin)

  #significance of within study variance
SBSUcommnovar2 <- rma.mv(logOR, v, mods = ~ Comm2, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(0,NA), tdist = TRUE, data=Data_SBSU)
anova(SBSUcomm,SBSUcommnovar2)

  #significance of between study variance
SBSUcommovar3 <- rma.mv(logOR, v, mods = ~ Comm2, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(NA,0), tdist = TRUE, data=Data_SBSU)
anova(SBSUcomm,SBSUcommovar3)

#Year of publication
year2 <- (Data_SBSU$yearp - 2010) #center around mean
SBSUpubyear <- rma.mv(logOR, v, mods = ~ year2, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUpubyear)

  #significance of within study variance
SBSUpubyearnovar2 <- rma.mv(logOR, v, mods = ~ year2, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(0,NA), tdist = TRUE, data=Data_SBSU)
anova(SBSUpubyear,SBSUpubyearnovar2)

  #significance of between study variance
SBSUpubyearovar3 <- rma.mv(logOR, v, mods = ~ year2, random = list(~ 1 | esID, ~ 1 | SampleID), sigma2=c(NA,0), tdist = TRUE, data=Data_SBSU)
anova(SBSUpubyear,SBSUpubyearovar3)

#Study quality
Poor2 <- ifelse(Data_SBSU$Quality=="1", yes=1, no=0)
Fair2 <- ifelse(Data_SBSU$Quality=="2", yes=1, no=0)
Good2 <- ifelse(Data_SBSU$Quality=="3", yes=1, no=0)
SBSUpoor <- rma.mv(logOR, v, mods = ~ Fair2 + Good2, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUpoor)
SBSUfair <- rma.mv(logOR, v, mods = ~ Poor2 + Good2, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUfair)
SBSUgood <- rma.mv(logOR, v, mods = ~ Poor2 + Fair2, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSU)
summary(SBSUgood)

##########################
###HYPOTHESIS COMPARISON
#########################

Data_all <- read_csv("Data all.csv")

ALLoverall <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_all)
summary(ALLoverall)

ALLdirection <- rma.mv(logOR, v, mods = ~ Dir, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_all)
summary(ALLdirection)

########################
###Publication bias
########################

#EGGER'S REGRESSION TEST

SEsusb <- sqrt(Data_SUSB$v)
SUSBegger <- rma.mv(logOR,v, mods = SEsusb, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data = Data_SUSB)
summary(SUSBegger)


SEsbsu <- sqrt(Data_SBSU$v)
SBSUegger <- rma.mv(logOR,v, mods = SEsbsu, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data = Data_SBSU)
summary(SBSUegger)

#FUNNEL PLOTS ALL

funnel(SUSBoverall)
funnel(SBSUoverall)

#TRIM AND FILL ANALYSIS

Data_SUSB_onepersample <- read_csv("Data one per sample SUSB.csv")

par(mar=c(5,4,1,2))

SUSB_onepersample <- rma(logOR, v, tdist = TRUE, data=Data_SUSB_onepersample, measure="OR")
summary(SUSB_onepersample)

SUSBtrimfill <- trimfill(SUSB_onepersample)
summary(SUSBtrimfill)
funnel(SUSBtrimfill)

Data_SBSU_onepersample <- read_csv("Data one per sample SBSU.csv")

SBSU_onepersample <- rma(logOR, v, tdist = TRUE, data=Data_SBSU_onepersample, measure="OR")
summary(SBSU_onepersample)

SBSUtrimfill <- trimfill(SBSU_onepersample)
summary(SBSUtrimfill)
funnel(SBSUtrimfill)

########################
###Sensitivity analyses
########################

#SUSB exclude very large samples

Data_SUSBnolarge <- Data_SUSB[-c(10, 18), ]

SUSBnolarge <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSBnolarge)
summary(SUSBnolarge)

#SUSB exclude Borges
Data_SUSBnoborges <- Data_SUSB[-c(1:5), ]
SUSBnoborges <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSBnoborges)
summary(SUSBnoborges)

#SUSB exclude Chang
Data_SUSBnochang <- Data_SUSB[-c(6:7), ]
SUSBnochang <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSBnochang)
summary(SUSBnochang)

#SUSB exclude Chavira
Data_SUSBnochav <- Data_SUSB[-c(8:9), ]
SUSBnochav <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSBnochav)
summary(SUSBnochav)

#SUSB exclude Chen
Data_SUSBnochen <- Data_SUSB[-c(10), ]
SUSBnochen <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSBnochen)
summary(SUSBnochen)

#SUSB exclude Clarke
Data_SUSBnoclarke <- Data_SUSB[-c(27), ]
SUSBnoclarke <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSBnoclarke)
summary(SUSBnoclarke)

#SUSB exclude Conner
Data_SUSBnoconner <- Data_SUSB[-c(11:14), ]
SUSBnoconner <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSBnoconner)
summary(SUSBnoconner)

#SUSB exclude cox lippard
Data_SUSBnocox <- Data_SUSB[-c(15), ]
SUSBnocox <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSBnocox)
summary(SUSBnocox)

#SUSB exclude Giacona
Data_SUSBnogia <- Data_SUSB[-c(16), ]
SUSBnogia <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSBnogia)
summary(SUSBnogia)

#SUSB exclude Goldstein
Data_SUSBnogold <- Data_SUSB[-c(17), ]
SUSBnogold <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSBnogold)
summary(SUSBnogold)

#SUSB exclude Hammerton
Data_SUSBnohamm <- Data_SUSB[-c(18), ]
SUSBnohamm <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSBnohamm)
summary(SUSBnohamm)

#SUSB exclude Hishinuma
Data_SUSBnohish <- Data_SUSB[-c(19), ]
SUSBnohish <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSBnohish)
summary(SUSBnohish)

#SUSB exclude King
Data_SUSBnoking <- Data_SUSB[-c(20), ]
SUSBnoking <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSBnoking)
summary(SUSBnoking)

#SUSB exclude Lewinsohn
Data_SUSBnolewin <- Data_SUSB[-c(28:31), ]
SUSBnolewin <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSBnolewin)
summary(SUSBnolewin)

#SUSB exclude Miranda
Data_SUSBnomir <- Data_SUSB[-c(21), ]
SUSBnomir <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSBnomir)
summary(SUSBnomir)

#SUSB exclude Olfson
Data_SUSBnoolf <- Data_SUSB[-c(26), ]
SUSBnoolf <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSBnoolf)
summary(SUSBnoolf)

#SUSB exclude Tuisku
Data_SUSBnotuis <- Data_SUSB[-c(22:25), ]
SUSBnotuis <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SUSBnotuis)
summary(SUSBnotuis)

#SBSU exclude copeland
Data_SBSUnocop <- Data_SBSU[-c(1:2), ]
SBSUnocop <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSUnocop)
summary(SBSUnocop)

#SBSU exclude dhosshe
Data_SBSUnodho <- Data_SBSU[-c(3), ]
SBSUnodho <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSUnodho)
summary(SBSUnodho)

#SBSU exclude fergusson
Data_SBSUnoferg <- Data_SBSU[-c(4:15), ]
SBSUnoferg <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSUnoferg)
summary(SBSUnoferg)

#SBSU exclude herba
Data_SBSUnoherba <- Data_SBSU[-c(16), ]
SBSUnoherba <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSUnoherba)
summary(SBSUnoherba)

#SBSU exclude Iorfino
Data_SBSUnoior <- Data_SBSU[-c(17:18), ]
SBSUnoior <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSUnoior)
summary(SBSUnoior)

#SBSU exclude Mars
Data_SBSUnomars <- Data_SBSU[-c(19:20), ]
SBSUnomars <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSUnomars)
summary(SBSUnomars)

#SBSU exclude Reinherz
Data_SBSUnorein <- Data_SBSU[-c(21:22), ]
SBSUnorein <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSUnorein)
summary(SBSUnorein)

#SBSU exclude Skarbo
Data_SBSUnoskar <- Data_SBSU[-c(23), ]
SBSUnoskar <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSUnoskar)
summary(SBSUnoskar)

#SBSU exclude Steinhausen
Data_SBSUnostein <- Data_SBSU[-c(24), ]
SBSUnostein <- rma.mv(logOR, v, random = list(~ 1 | esID, ~ 1 | SampleID), tdist = TRUE, data=Data_SBSUnostein)
summary(SBSUnostein)



