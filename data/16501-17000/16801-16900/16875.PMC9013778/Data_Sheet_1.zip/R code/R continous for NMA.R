install.packages("gemtc")
library(gemtc)
data<- read.csv("6AIS.csv", sep=",", header=T)
network <-mtc.network(data)
plot(network)
#Consistency model
model<-mtc.model(network, type="consistency",n.chain=3,likelihood="normal",link="identity",linearModel="random")
results<- mtc.run(model, n.adapt = 20000, n.iter = 50000, thin = 1)
summary(results)
forest(relative.effect(results, "MSC"))
forest(relative.effect(results, "OEC"))
forest(relative.effect(results, "Macrophage"))
forest(relative.effect(results, "NSC"))
forest(relative.effect(results, "Schwann"))
forest(relative.effect(results, "Baseline"))
forest(relative.effect(results, "Combined"))
plot(results)
gelman.plot(results)
ranks <- rank.probability(results)
print(ranks)
plot(ranks)
plot(ranks, beside = TRUE)
a <- round(relative.effect.table(results),2)
write.csv(a, "6AIS table.csv")

#inconsistency model
modelume<-mtc.model(network, type="ume", n.chain=3,likelihood="normal",link="identity",linearModel="random")
resultsume<- mtc.run(modelume, n.adapt = 20000, n.iter = 50000, thin = 1)
summary(resultsume)

#node-split
resultnodesplit <-mtc.nodesplit(network, n.adapt = 20000, n.iter= 50000, thin = 1, n.chain=3,likelihood="normal",link="identity",linearModel="random")
b<-summary(resultnodesplit)
print(b)
plot(b)

#heterogeneity for model
resultanohe <- mtc.anohe(network, n.adapt = 20000, n.iter =50000, thin = 1,n.chain=3,likelihood="normal",link="identity",linearModel="random")
c<-summary(resultanohe)
print(c)
plot(c)

#SUCRA
a<-ranks[,]
library(reshape2)

b<-melt(a)
c<-as.data.frame(b)

library(ggplot2)
p<-ggplot(c, aes(x=Var2, y=value, colour=Var1))+geom_line(size=1)

p1<-p+geom_point(size=2)+labs(x="Rank",y="Probability")+theme(axis.text = element_text(size=12),axis.title = element_text(size = 15),panel.background = element_blank( ),axis.line = element_line(color = "black"),legend.title = element_blank( ),legend.position = "bottom")

p2<-p+geom_point(size=2)+labs(x="Rank",y="Probability")+theme(axis.text = element_text(size=12),axis.title = element_text(size = 15),axis.line = element_line(color = "black"),legend.title = element_blank( ),legend.position = "bottom")


d<-t(apply(ranks, 1, cumsum))

e<-melt(d)

f<-as.data.frame(e)

p<-ggplot(f, aes(x=Var2, y=value, colour=Var1))+geom_line(size=1)

p1<-p+geom_point(size=2)+labs(x="Rank",y="Cumulative Probability")+theme(axis.text = element_text(size=12),axis.title = element_text(size = 15),panel.background = element_blank( ),axis.line = element_line(color = "black"),legend.title = element_blank( ),legend.position = "bottom")

p2<-p+geom_point(size=2)+labs(x="Rank",y="Cumulative Probability")+theme(axis.text = element_text(size=12),axis.title = element_text(size = 15),axis.line = element_line(color = "black"),legend.title = element_blank( ),legend.position = "bottom")

ggsave("6AIS.pdf", p2, width = 7.48, height = 6.48)
sucra<-function(ranks) {
  apply(ranks, 1, function(p) {
    a<- length(p)
    sum(cumsum(p[-a]))/(a-1)
  })
}
sucra(ranks)

#meta-regression
data<- read.csv("6AIS.csv", sep=",", header=T)
studies<-read.csv("6AISyear.csv",sep=",", header=T)

network <-mtc.network(data,studies=studies)
model<-mtc.model(network, type="regression",regressor=list(coefficient='unrelated', variable='year', control='Baseline'))  #?????????б?Ҫ?Ļ?һ?????Բ?ȫ??????ѡ??Ĭ?ϡ?
results<- mtc.run(model, n.adapt = 20000, n.iter = 50000, thin = 1)
summary(results)
plotCovariateEffect(results,t1='Baseline', t2=c('MSC', 'NSC', 'Macrophage', 'OEC','Schwann','Combined'))

