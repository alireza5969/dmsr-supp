install.packages("meta")
install.packages("metafor")
library(meta)
library(metafor)
library(Matrix)
data<- read.csv("meta.csv", sep=",", header=T)
head(data)

m.cont<- metacont(
  n.e, mean.e, sd.e,
  n.c, mean.c, sd.c,
  data=data,sm="SMD",label.e="Cell therapy", label.c="Baseline",
  studlab=paste(Study)
)                                       
summary(m.cont)

#choose model based on I2
m.cont_random<- metacont(
  n.e = n.e,
  mean.e = mean.e,
  sd.e = sd.e,
  n.c = n.c,
  mean.c = mean.c,
  sd.c = sd.c,
  studlab = Study,
  data = data,
  sm = "SMD",
  method.smd = "Hedges",
  comb.fixed = FALSE,
  comb.random = TRUE,
  method.tau = "REML",
  hakn = TRUE,
  title = "12AIS"
  
)

m.cont_random

forest(m.cont_random)

forest.meta(m.cont_random, layout = "JAMA")
forest.meta(m.cont_random, layout = "RevMan5")