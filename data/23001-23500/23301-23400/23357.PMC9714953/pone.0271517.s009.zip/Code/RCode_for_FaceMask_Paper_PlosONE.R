#Rscript of meta-analysis on face masks
#library(devtools)
library(data.table)
library(metafor)
library(metaviz)
library(meta)
#library(dmetar)
library(ggplot2)

dat<-fread("Data_facemask_intervention.csv", na.strings = "N/A")
dat$logOR=log(dat$OR)
dat$logORse=as.numeric(log(dat$ORupper)-log(dat$ORlower)) / (2*1.96)
#Remove totals
dat<-dat[-19,]
## Remove Abdin et al
dat_RR<-dat[-2,]

## Compute relative risk estimates for all studies

sink("Masks_RR_all.txt")
print(metagen(lnRR,
              lnRRse,
              data = dat_RR,
              comb.fixed = FALSE,
              comb.random = TRUE,
              method.tau = "DL",
              hakn = F,
              byvar = dat_RR$Setting,
              prediction = TRUE,
              sm = "RR",
              method.bias ="mm", 
              studlab = paste(Article)))
sink()

## Create figure RR all studies
RR=metagen(lnRR,
           lnRRse,
           data = dat_RR,
           comb.fixed = FALSE,
           comb.random = TRUE,
           method.tau = "DL",
           byvar = dat_RR$Setting,
           hakn = F,
           prediction = TRUE,
           sm = "RR",
           method.bias ="mm", 
           studlab = paste(Article))

pdf("Fig3_RR.pdf", width=9, height=7)
Fig3_RR_all<-forest(RR, col.fixed = "red", col.random = "blue", xlim = c(0.2, 2.5), sortvar = TE, print.subgroup.labels = T, digits = 3)
print(Fig3_RR_all)
dev.off()

## Compute RR values for sub groups

sink("Masks_RR_community.txt")
    print(metagen(lnRR,
                     lnRRse,
                     data = dat_RR,
                     comb.fixed = FALSE,
                     comb.random = TRUE,
                     method.tau = "DL",
                     hakn = F,
                     prediction = TRUE,
                     subset = dat_RR$Setting == "Community setting",
                     sm = "RR",
                     method.bias ="mm", 
                     studlab = paste(Article)))
sink()

## Create a figure for community setting
RR_community=metagen(lnRR,
                     lnRRse,
                     data = dat_RR,
                     comb.fixed = FALSE,
                     comb.random = TRUE,
                     method.tau = "DL",
                     hakn = F,
                     prediction = TRUE,
                     subset = dat_RR$Setting == "Community setting",
                     sm = "RR",
                     method.bias ="mm", 
                     studlab = paste(Article))

pdf("Fig3_RR_community.pdf", width=11, height=10)
Fig3_RR_community<-forest(RR_community, col.fixed = "red", col.random = "blue", xlim = c(0.2, 2.5), sortvar = TE, print.subgroup.labels = T, digits = 3)
print(Fig3_RR_community)
dev.off()

### Subgroup non community
sink("Masks_RR_non_community.txt")
print(metagen(lnRR,
              lnRRse,
              data = dat_RR,
              comb.fixed = FALSE,
              comb.random = TRUE,
              method.tau = "DL",
              hakn = F,
              prediction = TRUE,
              subset = dat_RR$Setting == "Non-community setting",
              sm = "RR",
              method.bias ="mm", 
              studlab = paste(Article)))
sink()

## Create a figure for non community setting
RR_non_community=metagen(lnRR,
                     lnRRse,
                     data = dat_RR,
                     comb.fixed = FALSE,
                     comb.random = TRUE,
                     method.tau = "DL",
                     hakn = F,
                     prediction = TRUE,
                     subset = dat_RR$Setting == "Non-community setting",
                     sm = "RR",
                     method.bias ="mm", 
                     studlab = paste(Article))

pdf("Fig3_RR_non_community.pdf", width=11, height=10)
Fig3_RR_non_community<-forest(RR_non_community, col.fixed = "red", col.random = "blue", xlim = c(0.2, 2.5), sortvar = TE, print.subgroup.labels = T, digits = 3)
print(Fig3_RR_non_community)
dev.off()

## Subgroup hospitals
sink("Masks_RR_hospitals.txt")
print(metagen(lnRR,
                     lnRRse,
                     data = dat_RR,
                     comb.fixed = FALSE,
                     comb.random = TRUE,
                     method.tau = "DL",
                     hakn = F,
                     prediction = TRUE,
                     subset = dat_RR$Population == "Hospitals",
                     sm = "RR",
                     method.bias ="mm", 
                     studlab = paste(Article)))
sink()

## Figure for Hospitals subgroup

RR_hospitals=metagen(lnRR,
                     lnRRse,
                     data = dat_RR,
                     comb.fixed = FALSE,
                     comb.random = TRUE,
                     method.tau = "DL",
                     hakn = F,
                     prediction = TRUE,
                     subset = dat_RR$Population == "Hospitals",
                     sm = "RR",
                     method.bias ="mm", 
                     studlab = paste(Article))
pdf("Fig3_RR_hospitals.pdf", width=11, height=10)
Fig3_RR_hospitals<-forest(RR_hospitals, col.fixed = "red", col.random = "blue", xlim = c(0.2, 2.5), sortvar = TE, print.subgroup.labels = T, digits = 3)
print(Fig3_RR_hospitals)
dev.off()

## Subgroup household
sink("Masks_RR_household.txt")
print(metagen(lnRR,
        lnRRse,
        data = dat_RR,
        comb.fixed = FALSE,
        comb.random = TRUE,
        method.tau = "DL",
        hakn = F,
        prediction = TRUE,
        subset = dat_RR$Population == "Household",
        sm = "RR",
        method.bias ="mm", 
        studlab = paste(Article)))
sink()

## Create a figure for household subgroup
RR_household=metagen(lnRR,
                     lnRRse,
                     data = dat_RR,
                     comb.fixed = FALSE,
                     comb.random = TRUE,
                     method.tau = "DL",
                     hakn = F,
                     prediction = TRUE,
                     subset = dat_RR$Population == "Household",
                     sm = "RR",
                     method.bias ="mm", 
                     studlab = paste(Article))

pdf("Fig3_RR_household.pdf", width=11, height=10)
Fig3_RR_household<-forest(RR_household, col.fixed = "red", col.random = "blue", xlim = c(0.2, 2.5), sortvar = TE, print.subgroup.labels = T, digits = 3)
print(Fig3_RR_household)
dev.off()

## Take studies that include also source control through randomization at cluster level
dat_RR_Sourcectrl<-subset(dat_RR, dat_RR$Includes_Source_Control == "Yes")

sink("Masks_RR_source_control.txt")
print(metagen(lnRR,
        lnRRse,
        data = dat_RR_Sourcectrl,
        comb.fixed = FALSE,
        comb.random = TRUE,
        method.tau = "DL",
        hakn = F,
        prediction = TRUE,
        sm = "RR",
        method.bias ="mm", 
        studlab = paste(Article)))
sink()

## Create a figure for include source control

RR_SourceControl=metagen(lnRR,
                     lnRRse,
                     data = dat_RR_Sourcectrl,
                     comb.fixed = FALSE,
                     comb.random = TRUE,
                     method.tau = "DL",
                     hakn = F,
                     prediction = TRUE,
                     sm = "RR",
                     method.bias ="mm", 
                     studlab = paste(Article))

pdf("Fig3_RR_SourceControl.pdf", width=11, height=10)
Fig3_RR_SourceControl<-forest(RR_SourceControl, col.fixed = "red", col.random = "blue", xlim = c(0.2, 2.5), sortvar = TE, print.subgroup.labels = T, digits = 3)
print(Fig3_RR_SourceControl)
dev.off()


## Compute estimates for studies that had adults only

dat_RR_Adults<-subset(dat_RR, Adults_only == "Yes")
sink("Masks_RR_adults_only.txt")
print(metagen(lnRR,
        lnRRse,
        data = dat_RR_Adults,
        comb.fixed = FALSE,
        comb.random = TRUE,
        method.tau = "DL",
        hakn = F,
        prediction = TRUE,
        #subset = dat_RR$Adults_only == "Yes",
        sm = "RR",
        method.bias ="mm", 
        studlab = paste(Article)))
sink()


RR_Adults=metagen(lnRR,
                         lnRRse,
                         data = dat_RR_Adults,
                         comb.fixed = FALSE,
                         comb.random = TRUE,
                         method.tau = "DL",
                         hakn = F,
                         prediction = TRUE,
                         subset = dat_RR_Adults$Adults_only == "Yes",
                         sm = "RR",
                         method.bias ="mm", 
                         studlab = paste(Article))

pdf("Fig3_RR_Adults.pdf", width=11, height=10)
Fig3_RR_Adults<-forest(RR_Adults, col.fixed = "red", col.random = "blue", xlim = c(0.2, 2.5), sortvar = TE, print.subgroup.labels = T, digits = 3)
print(RR_Adults)
dev.off()


### Leave one out analysis RR
pdf("Fig3_RR_Leave_one_out.pdf", width=11, height=10)
LOF<-viz_forest(x = dat_RR[, c("lnRR", "lnRRse")],
           study_labels = dat_RR$Articl,  method = "DL",
           xlab = "Risk Ratio", annotate_CI = T, x_trans_function = exp, 
           type = "sensitivity",
           summary_label = "Pooled Effect", 
           text_size = 2.8, x_limit = c(-2,1))
print(LOF)
dev.off()

#### Odds ratio analyses

dat$logOR=log(dat$OR)
dat$logORse=as.numeric(log(dat$ORupper)-log(dat$ORlower)) / (2*1.96)

## Meta-analyse all studies
sink("Fig_OR_all.txt")
print(metagen(logOR,
              logORse,
              data = dat,
              comb.fixed = FALSE,
              comb.random = TRUE,
              method.tau = "DL",
              hakn = F,
              prediction = TRUE,
              sm = "OR",
              method.bias ="mm", 
              studlab = paste(Article)))
sink()

## Create a figure for OR all studies

OR=metagen(logOR,
           logORse,
           data = dat,
           comb.fixed = FALSE,
           comb.random = TRUE,
           method.tau = "DL",
           hakn = F,
           byvar = dat$Setting,
           prediction = TRUE,
           sm = "OR",
           method.bias ="mm", 
           studlab = paste(Article))

pdf("Fig4_OR.pdf", width=8, height=7)
Fig4_OR<-forest(OR, col.fixed = "red", col.random = "blue", xlim = c(0.2, 2.5), sortvar = TE, print.subgroup.labels = T, digits = 3)
print(Fig4_OR)
dev.off()

## Compute estimate in community setting

sink("Fig4_OR_community_setting.txt")
print(metagen(logOR,
              logORse,
              data = dat,
              comb.fixed = FALSE,
              comb.random = TRUE,
              method.tau = "DL",
              hakn = F,
              prediction = TRUE,
              subset = Setting == "Community setting",
              sm = "OR",
              method.bias ="mm", 
              studlab = paste(Article)))
sink()

## Create figure for community setting

OR_community=metagen(logOR,
           logORse,
           data = dat,
           comb.fixed = FALSE,
           comb.random = TRUE,
           method.tau = "DL",
           hakn = F,
           prediction = TRUE,
           subset = Setting == "Community setting",
           sm = "OR",
           method.bias ="mm", 
           studlab = paste(Article))

forest(OR_community, col.fixed = "red", col.random = "blue", xlim = c(0.2, 2.5), sortvar = TE, print.subgroup.labels = T, digits = 3)

pdf("Fig4_OR_community.pdf", width=11, height=10)
Fig4_OR_community<-forest(OR_community, col.fixed = "red", col.random = "blue", xlim = c(0.2, 2.5), sortvar = TE, print.subgroup.labels = T, digits = 3)
print(Fig4_OR_community)
dev.off()

### Non community setting ##
sink("Fig4_OR_non_community_setting.txt")
print(metagen(logOR,
              logORse,
              data = dat,
              comb.fixed = FALSE,
              comb.random = TRUE,
              method.tau = "DL",
              hakn = F,
              prediction = TRUE,
              subset = Setting == "Non-community setting",
              sm = "OR",
              method.bias ="mm", 
              studlab = paste(Article)))
sink()

## Create figure for non community setting

OR_non_community=metagen(logOR,
                     logORse,
                     data = dat,
                     comb.fixed = FALSE,
                     comb.random = TRUE,
                     method.tau = "DL",
                     hakn = F,
                     prediction = TRUE,
                     subset = Setting == "Non-community setting",
                     sm = "OR",
                     method.bias ="mm", 
                     studlab = paste(Article))

forest(OR_non_community, col.fixed = "red", col.random = "blue", xlim = c(0.2, 2.5), sortvar = TE, print.subgroup.labels = T, digits = 3)

pdf("Fig4_OR_non_community.pdf", width=11, height=10)
Fig4_OR_non_community<-forest(OR_non_community, col.fixed = "red", col.random = "blue", xlim = c(0.2, 2.5), sortvar = TE, print.subgroup.labels = T, digits = 3)
print(Fig4_OR_non_community)
dev.off()



## Compute subgroup analysis in hospital setting

sink("Fig4_OR_hospital_setting.txt")
print(metagen(logOR,
                   logORse,
                   data = dat,
                   comb.fixed = FALSE,
                   comb.random = TRUE,
                   method.tau = "DL",
                   hakn = F,
                   prediction = TRUE,
                   subset = dat$Population == "Hospitals",
                   #byvar = dat$,
                   sm = "OR",
                   method.bias ="mm", 
                   studlab = paste(Article)))
sink()

## Create a figure for hospital setting

OR_hospitals=metagen(logOR,
                     logORse,
                     data = dat,
                     comb.fixed = FALSE,
                     comb.random = TRUE,
                     method.tau = "DL",
                     hakn = F,
                     prediction = TRUE,
                     subset = dat$Population == "Hospitals",
                     #byvar = dat$,
                     sm = "OR",
                     method.bias ="mm", 
                     studlab = paste(Article))

pdf("Fig4_OR_hospitals.pdf", width=10, height=6)
Fig4_OR_hospitals<-forest(OR_hospitals, col.fixed = "red", col.random = "blue", xlim = c(0.2, 2.5), sortvar = TE, print.subgroup.labels = T, digits = 3)
print(Fig4_OR_hospitals)
dev.off()

### Compute household setting

sink("Fig4_OR_household_setting.txt")
print(metagen(logOR,
              logORse,
              data = dat,
              comb.fixed = FALSE,
              comb.random = TRUE,
              method.tau = "DL",
              hakn = F,
              prediction = TRUE,
              subset = dat$Population == "Household",
              #byvar = dat$,
              sm = "OR",
              method.bias ="mm", 
              studlab = paste(Article)))
sink()

### Create a figure for household setting

OR_household=metagen(logOR,
                     logORse,
                     data = dat,
                     comb.fixed = FALSE,
                     comb.random = TRUE,
                     method.tau = "DL",
                     hakn = F,
                     prediction = TRUE,
                     subset = dat$Population == "Household",
                     #byvar = dat$,
                     sm = "OR",
                     method.bias ="mm", 
                     studlab = paste(Article))

OR_household
pdf("Fig4_OR_household.pdf", width=10, height=6)
Fig4_OR_household<-forest(OR_household, col.fixed = "red", col.random = "blue", xlim = c(0.2, 2.5), sortvar = TE, print.subgroup.labels = T, digits = 3)
print(Fig4_OR_household)
dev.off()

## Analyze adults only

dat_OR_Adults<-subset(dat, Adults_only == "Yes")
sink("Fig4_adults.txt")
print(metagen(logOR,
        logORse,
        data = dat_OR_Adults,
        comb.fixed = FALSE,
        comb.random = TRUE,
        method.tau = "DL",
        hakn = F,
        prediction = TRUE,
        subset = dat_OR_Adults$Adults_only == "Yes",
        sm = "OR",
        method.bias ="mm", 
        studlab = paste(Article)))
sink()

## Create figure for adults only
OR_adults=metagen(logOR,
                     logORse,
                     data = dat_OR_Adults,
                     comb.fixed = FALSE,
                     comb.random = TRUE,
                     method.tau = "DL",
                     hakn = F,
                     prediction = TRUE,
                     subset = dat_OR_Adults$Adults_only == "Yes",
                     sm = "OR",
                     method.bias ="mm", 
                     studlab = paste(Article))

OR_adults
pdf("Fig4_OR_adults.pdf", width=10, height=6)
Fig4_OR_adults<-forest(OR_adults, col.fixed = "red", col.random = "blue", xlim = c(0.2, 2.5), sortvar = TE, print.subgroup.labels = T, digits = 3)
print(Fig4_OR_adults)
dev.off()

## Analyze source control

dat_OR_SourceControl<-subset(dat, dat$Includes_Source_Control == "Yes")

sink("Fig4_OR_Source_Control.txt")
print(metagen(logOR,
              logORse,
              data = dat_OR_SourceControl,
              comb.fixed = FALSE,
              comb.random = TRUE,
              method.tau = "DL",
              hakn = F,
              prediction = TRUE,
              sm = "OR",
              method.bias ="mm", 
              studlab = paste(Article)))
sink()

## Create source control figure

OR_SourceControl=metagen(logOR,
                         logORse,
                         data = dat_OR_SourceControl,
                         comb.fixed = FALSE,
                         comb.random = TRUE,
                         method.tau = "DL",
                         hakn = F,
                         prediction = TRUE,
                         sm = "OR",
                         method.bias ="mm", 
                         studlab = paste(Article))

pdf("Fig4_OR_sourcecontrol.pdf", width=10, height=6)
Fig4_OR_SourceControl<-forest(OR_SourceControl, col.fixed = "red", col.random = "blue", xlim = c(0.2, 2.5), sortvar = TE, print.subgroup.labels = T, digits = 3)
print(Fig4_OR_SourceControl)
dev.off()

### Compute leave one out with odds ratios ###
pdf("Fig4_OR_LOF.pdf", width=10, height=6)
LOF_OR<-viz_forest(x = dat[, c("logOR", "logORse")],
                   study_labels = dat$Article,  method = "DL",
                   xlab = "Odds Ratio", annotate_CI = T, x_trans_function = exp, 
                   type = "sensitivity",
                   summary_label = "Pooled Effect", 
                   text_size = 2.8, x_limit = c(-2,1))
print(LOF_OR)
dev.off()
#### Compute OR and estimates for LOF_Simmerman
dat_OR_LOF_simmerman<-dat[-17,]
sink("LOF_Simmerman_OR.txt")
OR_LOF_simmerman=metagen(logOR,
                             logORse,
                             data = dat_OR_LOF_simmerman,
                             comb.fixed = FALSE,
                             comb.random = TRUE,
                             method.tau = "DL",
                             hakn = F,
                             prediction = TRUE,
                             sm = "OR",
                             method.bias ="mm", 
                             studlab = paste(Article))
print(OR_LOF_simmerman)
sink()
####### MASK WITH HAND HYGIENE #####

FM<-fread("Data_facemask_hand_hygiene_inte.csv")

### Compute face mask with hand hygiene using RRs

sink("Masks_with_hand_hygiene_RR_all.txt")
print(metagen(lnRR,
              lnRRse,
              data = FM,
              comb.fixed = FALSE,
              comb.random = TRUE,
              method.tau = "DL",
              hakn = F,
              prediction = TRUE,
              sm = "RR",
              method.bias ="mm", 
              studlab = paste(Article)))
sink()

## Create figure Face mask hand hygiene RR all studies
FMRR=metagen(lnRR,
           lnRRse,
           data = FM,
           comb.fixed = FALSE,
           comb.random = TRUE,
           method.tau = "DL",
           hakn = F,
           prediction = TRUE,
           sm = "RR",
           method.bias ="mm", 
           studlab = paste(Article))

pdf("FMHH_RR.pdf", width=11, height=10)
FMHH_RR_all<-forest(FMRR, col.fixed = "red", col.random = "blue", xlim = c(0.2, 2.5), sortvar = TE, print.subgroup.labels = T, digits = 3)
print(FMHH_RR_all)
dev.off()

### Compute face mask with hand hygiene using ORs

FM$logOR=log(FM$OR)
FM$logORse=as.numeric(log(FM$ORupper)-log(FM$ORlower)) / (2*1.96)
sink("FM_OR.txt")
print(metagen(logOR,
              logORse,
              data = FM,
              comb.fixed = FALSE,
              comb.random = TRUE,
              method.tau = "DL",
              hakn = F,
              prediction = TRUE,
              sm = "OR",
              method.bias ="mm", 
              studlab = paste(Article)))
sink()

FM_OR=metagen(logOR,
              logORse,
                     data = FM,
                     comb.fixed = FALSE,
                     comb.random = TRUE,
                     method.tau = "DL",
                     hakn = F,
                     prediction = TRUE,
                     sm = "OR",
                     method.bias ="mm", 
                     studlab = paste(Article))

FM_OR

pdf("Fig_FM_OR.pdf", width=10, height=6)
FM_OR_fig<-forest(FM_OR, col.fixed = "red", col.random = "blue", xlim = c(0.2, 2.5), sortvar = TE, print.subgroup.labels = T, digits = 3)
print(FM_OR_fig)
dev.off()

FM_LOF_simmermman <- FM[-2,]
metagen(logOR,
        logORse,
        data = FM_LOF_simmermman,
        comb.fixed = FALSE,
        comb.random = TRUE,
        method.tau = "DL",
        hakn = F,
        prediction = TRUE,
        sm = "OR",
        method.bias ="mm", 
        studlab = paste(Article))

### NNT ###

#Compute for OR = 0.88 and for RR = 0.89 with 0.01 and 0.1 BL risk
nnt(0.89, p.c = 0.01, sm = "RR") 
#NNT = 909.0909 --> NNT = 910
nnt(0.89, p.c = 0.1, sm = "RR")
#NNT = 90.909 --> NNT = 91

nnt(0.88, p.c = 0.01, sm = "OR")
#NNT = 840.74 --> NNT =  841
nnt(0.88, p.c = 0.1, sm = "OR")
#NNT = 91.48 --> NNT =  92

