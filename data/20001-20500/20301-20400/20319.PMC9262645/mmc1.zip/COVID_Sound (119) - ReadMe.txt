Supplementary Bib TeX file: COVID_Sound (119)

This bib file includes a list of bibliographic citations of the 119 included studies in this study.