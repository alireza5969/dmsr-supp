// A2 Successfully Fed Model

functions{
  real P_fed(real a_theta, real a, real b){ // Probability of successfully feeding
    return 1-(exp(b*(1-exp(a*a_theta))/a));
  }
}

data{
  
  int S; 
  int X_survive[S]; // Number of mosquitoes that survive
  int N_caught[S]; // Number of mosquitoes that are caught
  int X_succfed[S]; // Number successfully fed (N fed * Prop survived)
  
  int nsite; 
  int site[S]; // index for each site
  
  int S_sim;
  vector[S_sim] theta_sim;
  
}

parameters{
  
  real<lower=0, upper=1> theta[S]; // probability of surviving
  real<lower=0> a;
  real<lower=0> b;
  real phi[nsite];
  real<lower=0> sigma_phi;
}

model{
  
  // likelihood
  for(i in 1:S)
    X_survive[i] ~ binomial(N_caught[i],theta[i]);
    
  // prior for theta
  theta ~ uniform(0,1);
    
  // successfully fed
  for (i in 1:S)
  X_succfed[i] ~ binomial_logit(N_caught[i], logit(P_fed(theta[i],a,b)) + phi[site[i]]);
  
  // priors
  a ~ normal(8,0.3);
  b ~ normal(0,0.01); 

  // priors on random effects
  phi ~ normal(0,sigma_phi);
  sigma_phi ~ normal(0,1);
  
}

// for loglikelihood and credible intervals

generated quantities{
  vector[S_sim] P_fed_sim;
  vector[S] loglikelihood;
  for(i in 1:S_sim){
    P_fed_sim[i]= 1-(exp(b*(1-exp(a*theta_sim[i]))/a));
  }
  for(i in 1:S){
    loglikelihood[i]= (binomial_lpmf(X_survive[i]|N_caught[i],theta[i]) + 
    binomial_logit_lpmf(X_succfed[i] | N_caught[i], logit(P_fed(theta[i],a,b)) + phi[site[i]]));

   }
}
